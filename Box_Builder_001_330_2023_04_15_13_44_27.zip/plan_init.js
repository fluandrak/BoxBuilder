let planInit = () => {
  
  let pos = createVector(0, 0, 0);
  plan = new Plan(pos);
  
}
